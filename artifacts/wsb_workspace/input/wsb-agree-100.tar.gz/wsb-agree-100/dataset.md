# WSB-Agree-100

A 100-item slice of WorkspaceBench (WSB) for comparing looped models. Each item is labelled
**pass** or **fail** on WSB's answerability gate, and the label **agrees across looped models**.
There are 50 pass and 50 fail items, 25 from each of four families: multihop, directed_modulation,
poetry and conjunctive_association.

## What "pass" means
Each item is labelled with the WSB answerability gate result. An item passes iff the greedy answer is correct **and**
≥ 8 of 10 samples at T = 0.7 are correct. Grading uses WSB's own deterministic graders, with the
Haiku 5.5 LLM fallback (Batch API, effort medium, max_tokens 768) wherever WSB allows one. Families:
- **multihop**: the answer and every bridge question.
- **directed_modulation**: the compliance screen. The carrier sentence must be copied and the held concept must never surface.
- **poetry**: the model's own rhyme word.
- **conjunctive_association**: a *leak screen*. The item passes when no continuation states the composed
  latent. So a "pass" here means *did not leak*, not "solved", and is a different kind of label
  from the other three families.

## Models the labels are drawn from
`ouro-1.4b`, `ouro-2.6b`, `dory-4b`: Ouro-1.4B and Ouro-2.6B (4 recurrence steps, HF transformers),
and Dory1.0-4B (2 loops, thinking off, vLLM). Huginn-0125 was dropped, because Dory beats it everywhere and Huginn's
format failures (0/100 poetry, 2/100 directed_modulation) made the set unbalanceable.
Dory at other loop counts (1, 3 and 4) was **not** used for selection. Against `seed_0`'s labels, Dory at 1 / 2 / 3 / 4 loops
agrees on 82 / 89 / 81 / 80 of 100 items, so the labels are specific to the loop count.

## Criteria (every version satisfies all of them; checked by `agent/curate/verify.py`)
1. 100 items: 25 per family, 50 labelled pass and 50 labelled fail.
2. Label = the majority final gate result across the 3 models. **At most 1 model disagrees** with any item's label.
3. Every model's own pass share over the 100 items lies in **[0.45, 0.55]**.
4. Every family's pass-label share lies in **[0.40, 0.60]**, so the family does not give away the label.
5. Maximise the number of unanimous items (all 3 models agree). The optimum is 88/100.
   A fully unanimous set is infeasible: only 1 conjunctive_association item fails on all 3 models.

## Versions (seed-controlled)
The selection is an ILP (`agent/curate/curate.py`, scipy `milp`). The seed only changes which optimal set is
returned. It sets random tie-break weights, so every version meets every criterion, and the versions differ in which items they contain.
- **`seed_<s>`** (tier `max`, s = 0…9): unanimity at the optimum (88). Pairwise overlap between seeds:
  min 44, mean 49.6, max 57 items.
  11 items are in every seed, and 256 distinct items appear across the 10.
- **`seed_<s>_u85`** (tier `u85`): requires ≥ 85 unanimous items, with the objective otherwise random, which gives more diversity.
  Pairwise overlap: min 39, mean 46.4, max 55; union 273.

Note: Dory's pass share is 0.55 in every version, at the top of the allowed range. That is the binding constraint,
because Dory passes more items than the Ouros.

| version | unanimous | ouro-1.4b | ouro-2.6b | dory-4b | multihop: pass / unanimous | directed_modulation: pass / unanimous | poetry: pass / unanimous | conjunctive_association: pass / unanimous |
|---|---|---|---|---|---|---|---|---|
| `seed_0` | 88 | 0.50 | 0.51 | 0.55 | 12 / 24 | 13 / 23 | 10 / 25 | 15 / 16 |
| `seed_1` | 88 | 0.50 | 0.51 | 0.55 | 13 / 24 | 12 / 25 | 10 / 23 | 15 / 16 |
| `seed_2` | 88 | 0.50 | 0.51 | 0.55 | 11 / 23 | 14 / 25 | 10 / 24 | 15 / 16 |
| `seed_3` | 88 | 0.50 | 0.51 | 0.55 | 11 / 24 | 14 / 24 | 10 / 24 | 15 / 16 |
| `seed_4` | 88 | 0.50 | 0.51 | 0.55 | 11 / 24 | 13 / 25 | 11 / 23 | 15 / 16 |
| `seed_5` | 88 | 0.50 | 0.51 | 0.55 | 13 / 24 | 11 / 25 | 11 / 23 | 15 / 16 |
| `seed_6` | 88 | 0.50 | 0.51 | 0.55 | 12 / 24 | 13 / 24 | 10 / 24 | 15 / 16 |
| `seed_7` | 88 | 0.50 | 0.51 | 0.55 | 13 / 23 | 12 / 25 | 10 / 24 | 15 / 16 |
| `seed_8` | 88 | 0.50 | 0.51 | 0.55 | 12 / 24 | 13 / 25 | 10 / 23 | 15 / 16 |
| `seed_9` | 88 | 0.50 | 0.51 | 0.55 | 13 / 23 | 10 / 25 | 12 / 24 | 15 / 16 |
| `seed_0_u85` | 85 | 0.51 | 0.53 | 0.55 | 12 / 23 | 13 / 22 | 10 / 24 | 15 / 16 |
| `seed_1_u85` | 85 | 0.52 | 0.52 | 0.55 | 13 / 23 | 12 / 23 | 10 / 23 | 15 / 16 |
| `seed_2_u85` | 85 | 0.52 | 0.52 | 0.55 | 11 / 21 | 14 / 24 | 10 / 24 | 15 / 16 |
| `seed_3_u85` | 85 | 0.52 | 0.52 | 0.55 | 11 / 24 | 14 / 22 | 10 / 23 | 15 / 16 |
| `seed_4_u85` | 85 | 0.53 | 0.51 | 0.55 | 12 / 23 | 13 / 24 | 10 / 22 | 15 / 16 |
| `seed_5_u85` | 85 | 0.52 | 0.52 | 0.55 | 14 / 23 | 10 / 23 | 11 / 23 | 15 / 16 |
| `seed_6_u85` | 85 | 0.53 | 0.51 | 0.55 | 13 / 23 | 12 / 22 | 10 / 24 | 15 / 16 |
| `seed_7_u85` | 85 | 0.52 | 0.52 | 0.55 | 13 / 23 | 12 / 23 | 10 / 23 | 15 / 16 |
| `seed_8_u85` | 85 | 0.52 | 0.52 | 0.55 | 12 / 23 | 13 / 23 | 10 / 23 | 15 / 16 |
| `seed_9_u85` | 85 | 0.52 | 0.52 | 0.55 | 12 / 22 | 11 / 24 | 12 / 23 | 15 / 16 |

## Files (`agent/datasets/wsb-agree-100/`)
- `seed_<s>[_u85].jsonl`: one item per line, with `family`, `id`, `label`, `agree` (models agreeing), `unanimous`,
  `results` (per-model final gate pass) and `item` (the WSB bank item as stored in the gate log: prompt, golds, …).
- `seed_<s>[_u85].json`: the same items, plus the parameters and a summary.
- `index.json`: every version's summary and the overlap statistics.
- `wsb_agree.py`: loader.
- Full transcripts per model: `ext/workspace-bench/adapted/<model>/gate/<family>.jsonl` (match on `id`).
  The web app's "Dataset" filter shows them.

## Using / iterating over seeds
```python
import sys; sys.path.insert(0, "agent/datasets/wsb-agree-100")
from wsb_agree import load, versions
for tag in versions("max"):        # seed_0 … seed_9
    items = load(tag)              # 100 dicts
    score = my_eval(items)         # e.g. lens readout accuracy on pass vs fail items
```
Report results as the mean ± spread over seeds, rather than relying on a single version.

## Regenerating / new seeds / new models
```bash
cd agent/curate
../../.venv/bin/python curate.py --seed 42 --out agent/datasets/wsb-agree-100              # one more version
../../.venv/bin/python curate.py --seed 42 --min-unanimous 80 --out agent/datasets/wsb-agree-100
../../.venv/bin/python curate.py ouro-1.4b ouro-2.6b dory-4b dory-4b-L4 --seed 0            # add a model (prints only)
../../.venv/bin/python make_versions.py --seeds 10    # rebuild all 20 versions + index.json
../../.venv/bin/python verify.py                      # re-check every version from the gate logs
../../.venv/bin/python build_dataset_md.py            # regenerate this file
```
Other knobs: `--lo/--hi` (per-model pass share), `--fam-lo/--fam-hi`, `--fam-size MIN MAX`, `--max-disagree`, `--n`.
