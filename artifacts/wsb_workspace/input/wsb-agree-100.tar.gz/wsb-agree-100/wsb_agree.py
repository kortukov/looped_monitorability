"""Load / iterate WSB-Agree-100 versions.

    from wsb_agree import load, versions
    for tag in versions("max"):          # seed_0 .. seed_9
        items = load(tag)                # list of dicts: family, id, label, agree, unanimous, results, item
    items = load("seed_3_u85")

Each item's `item` is the WorkspaceBench bank item (prompt, golds, ...) as stored in the gate log;
the per-model gate records live in ext/workspace-bench/adapted/<model>/gate/<family>.jsonl (match on id).
"""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def versions(tier: str | None = None) -> list[str]:
    idx = json.loads((HERE / "index.json").read_text())
    tags = [t for t, v in idx["versions"].items() if tier is None or v["tier"] == tier]
    return sorted(tags, key=lambda t: (idx["versions"][t]["tier"], idx["versions"][t]["seed"]))


def load(tag: str) -> list[dict]:
    return [json.loads(l) for l in (HERE / f"{tag}.jsonl").read_text(encoding="utf-8").splitlines() if l]
